'''
input :
     input() is inbuilt function which read data from console/command line
     -default data type is str when we will read data from console/command line
     
type casting : is also known as type conversion
          int()  : to convert str to int
          str()  : to convert int to str
          etc
          
loop
break and continue

'''
a = input('enter data :')
b = input('enter data :')

print(type(a))
print(type(b))

c = a+b
print('sum of two values :',c)

a = int(a)#convert to int 
b = int(b)#convert to int 


print(type(a))
print(type(b))


c = a+b
print('sum of two values :',c)


