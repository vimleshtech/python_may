'''
break and continue
break : to terminate the loop or stop the loop
continue : to skip the current iteration of loop and resume from next
'''
#break
for x in range(1,10):
     if x % 4 ==0:
          break

     print(x)

#continue
for x in range(1,10):
     if x % 4 ==0:
          continue
     print(x)
     
     
