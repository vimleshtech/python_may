'''
loop : is iterator or repeation of statement
     Example:
     1 2 3.....100

     Concept of loop:
          -init/start from            : 1  
          -condition/limit            : 100   
          -increment/decrement/steps  : +1
     There are following types of loop:
     i. while loop
     ii. for loop
break and continue
'''
#while loop
i = 1 #init
while i<10: #condition
     print(i)
     i+=1   #incrementer 

#print in reverse order
i = 10
while i>0:
     print(i)
     i-=1


#print all odd numbers between 1 to 30
i =1
while i<=30:
     print(i)
     i+=2
     
#wap to print sum of all even and odd numbers between two given inputs
a = int(input('enter first no :'))
b = int(input('enter second no :'))
se =0
so = 0
while a<=b:
     if a % 2==0:#if no is even 
          se+=a
     else:
          so+= a

     a+=1
     
print('sum of all even no :',se)
print('sum of all odd num :',so)


          
#for loop
for i in range(1,10): #from 1 to <10 , default incrementer is 1
     print(i)


#print in reverse
for x in range(10,0,-1):
     print(x)


#for odd numbers
for x in range(1,10,2):
     print(x)



     



     
     



     



